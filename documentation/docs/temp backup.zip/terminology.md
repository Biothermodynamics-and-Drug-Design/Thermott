# ...Terminology

![](./images/Under_construction_icon-yellow2.svg.png)

<span style="color:blue">PAGE UNDER CONSTRUCTION</span>
<span style="color:blue">info bus sumerginta su main txt</span>

*Thermott* specific terms used in the software

___

* *Experiment wells* 
* *Binding experiment*
* *Melting curve*



