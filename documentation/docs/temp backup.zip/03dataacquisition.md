# Running an experiment



![](./images/Under_construction_icon-yellow2.svg.png)

<span style="color:blue">PAGE UNDER CONSTRUCTION</span>

<span style="color:blue">Running an experiment / Data acquisition</span>



