# ...Sample data

![](./images/Under_construction_icon-yellow2.svg.png)

<span style="color:blue">PAGE UNDER CONSTRUCTION</span>
<span style="color:blue">info bus sumerginta su main txt</span>

Here we present samples of raw data and sessions.
___
## Ligand/protein binding experiments

### Human Hsp90αN binding with ICPD-26 ligand
* [Raw data (Generic CSV format)](./sample/SampleData_Hsp90aN_ICPD26_GenericCSV.csv)
* [Session](./sample/SampleData_Hsp90aN_ICPD26_GenericCSV.json)

___
## Protein stability experiments