# Data processing

![](./images/Under_construction_icon-yellow2.svg.png)

<span style="color:blue">PAGE UNDER CONSTRUCTION</span>


## RAW DATA

<span style="color:blue">raw data related info</span>

## METADATA

<span style="color:blue">metadata info</span>

## BINDING

<span style="color:blue">data fitting related info</span>



