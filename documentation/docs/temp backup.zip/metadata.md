# ...Metadata

![](./images/Under_construction_icon-yellow2.svg.png)

<span style="color:blue">PAGE UNDER CONSTRUCTION</span>
<span style="color:blue">info bus sumerginta su main txt</span>

Metadata is information about the performed experiment. It helps provide documentation and data is required for further binding analysis.

Here we provide information about using different metadata interfaces in *Thermott*. These interfaces can be found in the *Metadata* tab.



## Experiment well editor
___
Spreadsheet where you can manually edit properties of experiment wells.
The spreadsheet supports copy-paste from other spreadsheets (Microsoft Excel, LibreOffice Calc).


!!! note
    You can apply a value to all cells in a column by right mouse clicking it's header.


## Experiment builder
___
An interface creating binding experiments for determining protein/ligand binding strength (K<sub>b</sub>/K<sub>d</sub>)

*A binding experiment* is made of:

* *Experiment wells* (T<sub>m</sub> data)
* Metadata about the *binding experiment*:
    * protein conc., protein name, ligand name
    * protein specific thermodynamic parameters

*Binding experiment* can be created by selecting *experiment wells* from the list on the left and clicking **Create binding experiment** button. Created *binding experiment* will appear in the table on the right.


!!! Note "Adding/Removing *experiment wells*"
    *Experiment wells* can be removed afterwards by expanding the binding experiment and click the trash icon. *Experiment wells* can also be added  by dragging them from the list.

!!! Warning "*Experiment well* copies"
    By default *experiment well* copies are shown, meaning you are allowed to add *experiment wells* multiple times to different *binding experiments*. Usually we only add *experiment wells* once, thus it is useful to only see unused *experiment wells*. To toggle showing of copies one can click *circle* icon in the *Experiment wells* list



