# ...Protein melting analysis

![](./images/Under_construction_icon-yellow2.svg.png)

<span style="color:blue">PAGE UNDER CONSTRUCTION</span>
<span style="color:blue">info bus sumerginta su main txt</span>

Analysis is started in *"Raw data"* tab.

After the data has been [uploaded](#raw-data-upload), parsed and fitted, you can view individual melting curves of your samples (i.e. *experiment wells*). You change the selected *experiment well* by clicking in the *"Experiment wells"* list.

!!!Note "Selecting multiple *experiment wells*"
    You can click experiment wells with *Ctrl* and *Shift* keys to view several experiment wells at once.

You can refit the data by selecting a new fitting range just by click-dragging with mouse. You can change the model used for each *experiment well* by clicking on the [model](#melting-curve-models) name above the graph.

### Export *T<sub>m</sub>* values and curve data
You can export the fitted *T<sub>m</sub>* values in the *"Summary"* dialog (underneath *"Experiment wells"* list). Graphing data can be exported by click on the cog icon under the graph.


### Graph/heatmaps
Melting graphs and heatmaps in SVG/PNG format can be exported in the *"Heatmap"* and *"Report chart"* dialogs respectively (underneath *"Experiment wells"* list).

./images/binding_screenshot.png
[![Graph/Heatmap](./images/meltingcurve_graph_heatmap.png)](./images/meltingcurve_graph_heatmap.png)



## Raw data upload
___
The first step in data analysis is uploading your TSA/DSF experiment raw data:

1. Go to **Raw data** tab
2. Click **Upload**
3.  In the dialog select:
    * Your raw data file
    * File's [raw data format](/dataupload/#supported-raw-data-formats)
    * [Model](#melting-curve-models) used to fit melting curves 
4. Click **Upload**
5. Data will be uploaded, parsed and melting curves fitted.

If successful you should see a list of your samples on the left.


## Supported raw data formats
___
### Generic CSV (.csv)
It is a generic format that is meant to be used when the your TSA/DSF device native format is not supported. Users are required to convert to this format themselves.

Format example:

| Temperature |  Exp. 1 | Exp. 2 | Exp. 3 | Exp. 4 | ... |
|-------------|---------|--------|--------|--------|-----|
| 25          | 16.55   | 19.81  | 21.82  | 20.85  | ... |
| 25.5        | 16.39   | 19.72  | 21.68  | 20.72  | ... |
| 26          | 16.49   | 19.62  | 21.61  | 20.65  | ... |
| 26.5        | 16.39   | 19.46  | 21.48  | 20.61  | ... |
| 27          | 16.36   | 19.52  | 21.44  | 20.56  | ... |
| ...         | ...     | ...    | ...    | ...    | ... |

First column has to be named **"Temperature"** and contain increasing temperatures in celsius.

Other columns are for fluorescence data from samples. Column header can be a string (e.g. sample name, conditions) or just a number.

### RotorGeneQ Excel data sheet (transposed) (.csv)
Export format when performing experiments with *Corbett Rotor-Gene Real Time PCR Machine*

### RotorGene experiment (.rex)
Native format when performing experiments with *Corbett Rotor-Gene Real Time PCR Machine*



## Melting curve models
___
*Thermott* supports several melting curve models to fit your data. Melting curve models are used to determine melting temperature (*T<sub>m</sub>*). 

### Thermodynamic

 Model is  described by [Pantoliano (2001)](https://doi.org/10.1177/108705710100600609) and [Matulis (2005)](https://doi.org/10.1021/bi048135v).

$$
y(T) = y_f+y_{fs} (T-T_m) + \frac{y_u -y_f+ (y_{us} -y_{fs}) (T-T_m)}{1+e^{\Delta_U H\left(1 - \frac{T}{T_m}\right) +\Delta_U C_p\left( T- T_m  - T \ln\left(\frac{T}{T_m}  \right)\right)/RT}}
$$

### Derivative

Melting temperature in the derivative model is simply assumed from maxima of the first-order derivative of fluorescence data. The derivative for numeric data can be calculated by equation:

$$
y'(\frac{T_{n+1}+T_n}{2}) \approx \frac{y_{n+1}}{y_{n}}
$$

We additionally use signal filtering and then cubic interpolation to achieve a more accurate melting temperature. 

### Boltzmann

Most other software determines melting temperature using Boltzmann model: 

$$
y(T) = y_f + \frac{y_f - y_u}{1+e^{(T_m-T)/k}}
$$

Modified Boltzmann model (Boltzmann *) differs by modelling pre and post transition curves:

$$
y(T) = y_f+y_{fs} (T-T_m) + \frac{y_u -y_f+ (y_{us} -y_{fs}) (T-T_m)}{1+e^{(T_m-T)/k}}
$$

