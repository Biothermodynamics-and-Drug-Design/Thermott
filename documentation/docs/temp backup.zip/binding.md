# ...Ligand binding analysis

![](./images/Under_construction_icon-yellow2.svg.png)

<span style="color:blue">PAGE UNDER CONSTRUCTION</span>
<span style="color:blue">info bus sumerginta su main txt</span>


Analysis used to determine protein/ligand binding interaction strength (K<sub>b</sub>/K<sub>d</sub>).

Interface can be found in the *"Binding"* tab. Requires [creating binding experiments](../metadata/#experiment-builder).

[![Binding analysis tab](./images/binding_screenshot.png)](./images/binding_screenshot.png)

## Fitting data
K<sub>b</sub>/K<sub>d</sub> can be determined automatically by  selecting a *binding experiment* and pressing the *"Fit"* button. The value can be input manually by pressing *pencil* icon. 

## Graph export
Ligand-protein binding graphs can be exported in the *"Report chart"* dialog. Graph data can be exported by click *"Graph data"* button.

## K<sub>b</sub>/K<sub>d</sub> value export
 Can be exported in the *"Summary"* dialog. 

##Model
___
Equation here
